/*
 * Melak Mussie Yossief
 * Class:CS 30S
 * Assignment:00 Review assignment
 */
package binconvert;

/**
 *
 * @author yossief-m
 */
//import javax.swing.*;
// import java.text.DecimalFormat;
 import java.io.*;                            // import file io libraries
public class BinConvert {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        final int COUNTINGoffset = 1;          //Countingoffset is equal to 1 in order to avoid cunfusion
        
        String line;                          //input line 
        int i=0;
        int x=0;
        int n = 0;
        int l = 0;
        
      BufferedReader fin = new BufferedReader(new FileReader("numbers.txt")); //imports and reads file
      line=fin.readLine();                                                    // line stores values the bufferreader has
    
         while(line!=null){                                                   //as long as there's something to run this will run
         System.out.println(line);
        
         n = 0;
         x = 0;
         String[] num;
         num = line.split("");                  //split line using delimeter empty string which splits every charcter
         l = line.length()- COUNTINGoffset;     //the length of line subtracted by 1 because JS start count at 0
         
         for(i=l;i>=0;i--){                     // i is equal to length-1 so no matter how big the number it will run correctly
             int b = Integer.parseInt(num[x]);  //integer b converts num from a string to a number and store it           
             n += b * Math.pow(2, i);           //i decrementsand is the power with which we multiply,values are continuoisly added to n
             x++;
   }                                            //end of for lop
     System.out.println(n);                     //print ot the total value
     line=fin.readLine();                       //reads next line
      }                                         //end of while loop
    }                                           // end of class
    
}                                               //end of package
